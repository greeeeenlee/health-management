<?php
	$con=mysqli_connect("localhost","dlchfhr1211","mc!01029092120","dlchfhr1211");
	
	$userID=$_POST["userID"];
	$userMeal=$_POST["userMeal"];
	$userMealtime=$_POST["userMealtime"];
	$userBloodsugar=$_POST["userBloodsugar"];
	
	$statement=mysqli_prepare($con,"DELETE FROM BLOODSUGARS WHERE userID=? AND userMeal=? AND userMealtime=? AND userBloodsugar=?");
	mysqli_stmt_bind_param($statement,"ssss",$userID,$userMeal,$userMealtime,$userBloodsugar);
	mysqli_stmt_execute($statement);

	$response=array();
	$response["success"]=true;

	echo json_encode($response);
?>