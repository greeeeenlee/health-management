<?php
	$con=mysqli_connect("localhost","dlchfhr1211","mc!01029092120","dlchfhr1211");
	
	$userID=$_POST["userID"];
	$userBpmin=$_POST["userBpmin"];
	$userBpmax=$_POST["userBpmax"];
	
	$statement=mysqli_prepare($con,"DELETE FROM BLOODPRESSURES WHERE userID=? AND userBpmin=? AND userBpmax=?");
	mysqli_stmt_bind_param($statement,"sss",$userID,$userBpmin,$userBpmax);
	mysqli_stmt_execute($statement);

	$response=array();
	$response["success"]=true;

	echo json_encode($response);
?>