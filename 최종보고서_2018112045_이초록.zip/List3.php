<?php
	$con=mysqli_connect("localhost","dlchfhr1211","mc!01029092120","dlchfhr1211");
	$result=mysqli_query($con,"SELECT * FROM BLOODPRESSURES;");
	$response=array();
	
	while($row=mysqli_fetch_array($result)){
		array_push($response,array("userID"=>$row[0],"userBpmin"=>$row[1],"userBpmax"=>$row[2],"userDate"=>$row[3]));
	}

	echo json_encode(array("response"=>$response));
	mysqli_close($con);
?>