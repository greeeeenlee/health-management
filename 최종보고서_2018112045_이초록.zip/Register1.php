<?php 
    $con = mysqli_connect("localhost", "dlchfhr1211", "mc!01029092120", "dlchfhr1211");
    mysqli_query($con,'SET NAMES utf8');

    $userID = $_POST["userID"];
    $userPassword = $_POST["userPassword"];
    $userName = $_POST["userName"];
    $userGender = $_POST["userGender"];
    $userBirth = $_POST["userBirth"];
    $userHeight = $_POST["userHeight"];
    $userWeight = $_POST["userWeight"];
    $userDb = $_POST["userDb"];
    $userHbp = $_POST["userHbp"];


    $statement = mysqli_prepare($con, "INSERT INTO MEMBER VALUES (?,?,?,?,?,?,?,?,?)");
    mysqli_stmt_bind_param($statement, "sssssssss", $userID, $userPassword, $userName,$userGender,$userBirth,$userHeight,$userWeight,$userDb,$userHbp);
    mysqli_stmt_execute($statement);


    $response = array();
    $response["success"] = true;
 
   
    echo json_encode($response);



?>