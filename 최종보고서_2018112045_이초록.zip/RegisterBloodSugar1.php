<?php 
    $con = mysqli_connect("localhost", "dlchfhr1211", "mc!01029092120", "dlchfhr1211");
    mysqli_query($con,'SET NAMES utf8');

    $userID = $_POST["userID"];
    $userMeal= $_POST["userMeal"];
    $userMealtime = $_POST["userMealtime"];
    $userBloodsugar = $_POST["userBloodsugar"];



    $statement = mysqli_prepare($con, "INSERT INTO BLOODSUGARS VALUES (?,?,?,?,now())");
    mysqli_stmt_bind_param($statement, "ssss", $userID, $userMeal, $userMealtime,$userBloodsugar);
    mysqli_stmt_execute($statement);


    $response = array();
    $response["success"] = true;
 
   
    echo json_encode($response);



?>