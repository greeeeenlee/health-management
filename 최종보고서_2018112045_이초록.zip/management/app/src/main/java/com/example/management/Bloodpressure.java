package com.example.management;

public class Bloodpressure {
    String userID;
    String userBpmin;
    String userBPmax;



    String userDate;

    public Bloodpressure(String userID, String userBpmin, String userBPmax,String userDate) {
        this.userID = userID;
        this.userBpmin = userBpmin;
        this.userBPmax = userBPmax;
        this.userDate=userDate;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserBpmin() {
        return userBpmin;
    }

    public void setUserBpmin(String userBpmin) {
        this.userBpmin = userBpmin;
    }

    public String getUserBPmax() {
        return userBPmax;
    }

    public void setUserBPmax(String userBPmax) {
        this.userBPmax = userBPmax;
    }

    public String getUserDate() { return userDate; }

    public void setUserDate(String userDate) { this.userDate = userDate;}

}
