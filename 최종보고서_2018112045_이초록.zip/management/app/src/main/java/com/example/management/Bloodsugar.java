package com.example.management;

public class Bloodsugar {
    String userID;
    String userMeal;
    String userMealtime;
    String userBloodsugar;
    String userDate;

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public void setUserMeal(String userMeal) {
        this.userMeal = userMeal;
    }

    public void setUserMealtime(String userMealtime) {
        this.userMealtime = userMealtime;
    }

    public void setUserBloodsugar(String userBloodsugar) {
        this.userBloodsugar = userBloodsugar;
    }

    public void setUserDate(String userDate) { this.userDate=userDate; }

    public String getUserID() {
        return userID;
    }

    public String getUserMeal() {
        return userMeal;
    }

    public String getUserMealtime() {
        return userMealtime;
    }

    public String getUserBloodsugar() {
        return userBloodsugar;
    }

    public String getUserDate(){ return  userDate; }


    public Bloodsugar(String userID, String userMeal, String userMealtime, String userBloodsugar,String userDate) {
        this.userID = userID;
        this.userMeal = userMeal;
        this.userMealtime = userMealtime;
        this.userBloodsugar = userBloodsugar;
        this.userDate=userDate;
    }


}
