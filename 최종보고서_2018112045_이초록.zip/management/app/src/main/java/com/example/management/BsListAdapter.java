package com.example.management;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.List;

public class BsListAdapter extends BaseAdapter {
    private Context context;
    private List<Bloodsugar> bsList;
    private List<Bloodsugar> myList;
    private Activity parentActivity;

    public BsListAdapter(Context context, List<Bloodsugar> bsList, List<Bloodsugar> myList, Activity parentActivity){
        this.context=context;
        this.bsList=bsList;
        this.myList=myList;
        this.parentActivity=parentActivity;
    }

    @Override
    public int getCount() {
        return myList.size();
    }

    @Override
    public Object getItem(int i) {
        return myList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        View v=View.inflate(context,R.layout.bloodsugar,null);
        final TextView userID=(TextView)v.findViewById(R.id.userID);
        final TextView userMeal=(TextView)v.findViewById(R.id.userMeal);
        final TextView userMealtime=(TextView)v.findViewById(R.id.userMealtime);
        final TextView userBloodsugar=(TextView)v.findViewById(R.id.userBloodsugar);
        final TextView userDate=(TextView)v.findViewById(R.id.userDate);

        userID.setText(myList.get(i).getUserID());
        userMeal.setText(myList.get(i).getUserMeal());
        userMealtime.setText(myList.get(i).getUserMealtime());
        userBloodsugar.setText(myList.get(i).getUserBloodsugar());
        userDate.setText(myList.get(i).getUserDate());

        v.setTag(myList.get(i).getUserID());

        Button btn_delete=(Button) v.findViewById(R.id.btn_delete);
        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response.Listener<String> responseListener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try{
                            JSONObject jsonResponse=new JSONObject(response);
                            boolean success=jsonResponse.getBoolean("success");
                            if(success){
                                bsList.remove(i);
                                myList.remove(i);
                                notifyDataSetChanged();
                            }
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                };
                DeletebsRequest deletebsRequest=new DeletebsRequest(userID.getText().toString(),userMeal.getText().toString(),userMealtime.getText().toString(),userBloodsugar.getText().toString(),responseListener);
                RequestQueue queue= Volley.newRequestQueue(parentActivity);
                queue.add(deletebsRequest);
            }
        });

        return v;
    }
}
