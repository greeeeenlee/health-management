package com.example.management;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class DiagnoseActivity extends AppCompatActivity {

    private Button btn_diagnose_hbp,btn_diagnose_db;
    private TextView tv_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diagnose);

        btn_diagnose_hbp=findViewById(R.id.btn_diagnose_hbp);
        btn_diagnose_db=findViewById(R.id.btn_diagnose_db);
        tv_id=findViewById(R.id.tv_id);

        Intent intent=getIntent();
        String userID=intent.getStringExtra("userID");
        final String userGender=intent.getStringExtra("userGender");
        final String userBirth=intent.getStringExtra("userBirth");
        final String userDb=intent.getStringExtra("userDb");
        final String userHbp=intent.getStringExtra("userHbp");
        final String userHeight=intent.getStringExtra("userHeight");
        final String userWeight=intent.getStringExtra("userWeight");

        tv_id.setText(userID);

        btn_diagnose_hbp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),DiagnoseActivity_hbp.class);
                intent.putExtra("userID",tv_id.getText().toString());
                intent.putExtra("userGender",userGender);
                intent.putExtra("userBirth",userBirth);
                intent.putExtra("userDb",userDb);
                intent.putExtra("userHbp",userHbp);
                intent.putExtra("userHeight",userHeight);
                intent.putExtra("userWeight",userWeight);
                startActivity(intent);
            }
        });
        btn_diagnose_db.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(getApplicationContext(),DiagnoseActivity_db.class);
                intent1.putExtra("userID",tv_id.getText().toString());
                intent1.putExtra("userGender",userGender);
                intent1.putExtra("userBirth",userBirth);
                intent1.putExtra("userDb",userDb);
                intent1.putExtra("userHbp",userHbp);
                intent1.putExtra("userHeight",userHeight);
                intent1.putExtra("userWeight",userWeight);
                startActivity(intent1);
            }
        });

    }

}
