package com.example.management;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;

public class DiagnoseActivity_db extends AppCompatActivity {

    private TextView tv_id,tv_result;
    double bs,result,db_h;
    String userID,userGender,userBirth,userDb,finalresult;
    int userHeight,userWeight,age;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diagnose_db);

        tv_id=findViewById(R.id.tv_id);
        tv_result=findViewById(R.id.tv_result);

        Intent intent=getIntent();
        userID=intent.getStringExtra("userID");
        userGender=intent.getStringExtra("userGender");
        userBirth=intent.getStringExtra("userBirth");
        userDb=intent.getStringExtra("userDb");
        userHeight=Integer.parseInt(intent.getStringExtra("userHeight"));
        userWeight=Integer.parseInt(intent.getStringExtra("userWeight"));

        int birthyear=Integer.parseInt(userBirth.substring(0,4));//생년월일에서 년도 추출
        int birthmonth=Integer.parseInt(userBirth.substring(4,6));//생년월일에서 월 추출
        int birthday=Integer.parseInt(userBirth.substring(6,8));//생년월일에서 일자 추출

        Calendar cal=Calendar.getInstance();
        int nowyear=cal.get(Calendar.YEAR);//현재 년도 추출
        int nowmonth=cal.get(Calendar.MONTH)+1;//현재 월 추출
        int nowday=cal.get(Calendar.DAY_OF_MONTH);//현재 날짜 추출

        age=nowyear-birthyear;   //만나이 계산
        if(birthmonth*100+birthday>nowmonth*100+nowday)
            age--;

        tv_id.setText(userID);


        if(userDb.equals("yes"))
            db_h=1.0;
        else
            db_h=0.0;

        Response.Listener<String> responseListener=new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try{
                    JSONObject jsonObject=new JSONObject(response);
                    boolean success=jsonObject.getBoolean("success");
                    if(success){
                        bs =Double.parseDouble(jsonObject.getString("userBloodsugar"));

                        //성별이 여자인 경우
                        if(userGender.equals("여자")){
                            //result=-1.13787+0.006148*나이-0.00295*신장+0.005897*체중+0.021124*가족력+0.02395*공복혈당
                            result=-1.13787+0.006148*age-0.00295*userHeight+0.005897*userWeight+0.021124*db_h+0.02395* bs;
                        }
                        //성별이 남자인 경우
                        else{
                            //result=-0.7806+0.009677*나이-0.00366*신장+0.007238*체중+0.038858*가족력+0.018884*공복혈당
                            result=-0.7806+0.009677*age-0.00366*userHeight+0.007238*userWeight+0.038858*db_h+0.018884*bs;
                        }

                        if(result>=0&&result<1.5){
                            finalresult="정상입니다.";
                        }
                        else if(result>=1.5&&result<2.5){
                            finalresult="공복혈당장애가 의심됩니다.";
                        }
                        else if(result>=2.5&&result<3.5){
                            finalresult="당뇨병이 의심됩니다.";
                        }
                        else{
                            finalresult="입력된 데이터를 확인하세요.";
                        }

                        tv_result.setText(finalresult);
                    }
                    else{//혈당이 없는 경우
                        Toast.makeText(getApplicationContext(),"혈당을 입력해야 합니다.",Toast.LENGTH_LONG).show();
                        return;
                    }
                }catch (JSONException e){
                    e.printStackTrace();
                }
            }
        };

        Getbs getbs=new Getbs(userID,responseListener);
        RequestQueue queue= Volley.newRequestQueue(DiagnoseActivity_db.this);
        queue.add(getbs);

    }
}