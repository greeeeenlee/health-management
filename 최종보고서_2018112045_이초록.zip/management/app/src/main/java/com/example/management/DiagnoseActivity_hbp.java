package com.example.management;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;

public class DiagnoseActivity_hbp extends AppCompatActivity {

    private TextView tv_id,tv_result;
    double bpmin,bpmax,result,hbp_h;
    String userID,userGender,userBirth,userHbp,finalresult;
    int userHeight,userWeight,age;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diagnose_hbp);

        tv_id=findViewById(R.id.tv_id);
        tv_result=findViewById(R.id.tv_result);

        Intent intent=getIntent();
        userID=intent.getStringExtra("userID");
        userGender=intent.getStringExtra("userGender");
        userBirth=intent.getStringExtra("userBirth");
        userHbp=intent.getStringExtra("userHbp");
        userHeight=Integer.parseInt(intent.getStringExtra("userHeight"));
        userWeight=Integer.parseInt(intent.getStringExtra("userWeight"));

        int birthyear=Integer.parseInt(userBirth.substring(0,4));//생년월일에서 년도 추출
        int birthmonth=Integer.parseInt(userBirth.substring(4,6));//생년월일에서 월 추출
        int birthday=Integer.parseInt(userBirth.substring(6,8));//생년월일에서 일자 추출

        Calendar cal=Calendar.getInstance();
        int nowyear=cal.get(Calendar.YEAR);//현재 년도 추출
        int nowmonth=cal.get(Calendar.MONTH)+1;//현재 월 추출
        int nowday=cal.get(Calendar.DAY_OF_MONTH);//현재 날짜 추출

        age=nowyear-birthyear;   //만나이 계산
        if(birthmonth*100+birthday>nowmonth*100+nowday)
            age--;

        tv_id.setText(userID);

        if(userHbp.equals("yes"))
            hbp_h=1.0;
        else
            hbp_h=0.0;

        final Response.Listener<String> responseListener=new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    boolean success = jsonObject.getBoolean("success");
                    if (success) {
                        bpmin = Double.parseDouble(jsonObject.getString("userBpmin"));
                        bpmax = Double.parseDouble(jsonObject.getString("userBpmax"));

                        //성별이 여자인 경우
                        if (userGender.equals("여자")) {
                            //result=-1.66057+0.014401*나이-0.00998*신장+0.007795*체중+0.025275*수축기+0.01139*이완기-0.069158*가족력
                            result=-1.66057+0.014401*age-0.00998*userHeight+0.007795*userWeight+0.025275*bpmax+0.01139*bpmin-0.069158*hbp_h;
                        }
                        //성별이 남자인 경우
                        else {
                            //result=-2.3199+0.015338*나이-0.0091*신장+0.009008*체중+0.024003*수축기+0.019474*이완기+0.099263*가족력
                            result=-2.3199+0.015338*age-0.0091*userHeight+0.009008*userWeight+0.024003*bpmax+0.019474*bpmin+0.099263*hbp_h;
                        }

                        if(result>=0&&result<1.5){
                            finalresult="정상입니다.";
                        }
                        else if(result>=1.5&&result<2.5){
                            finalresult="고혈압전단계가 의심됩니다.";
                        }
                        else if(result>=2.5&&result<3.5){
                            finalresult="고혈압 의심됩니다.";
                        }
                        else{
                            finalresult="입력된 데이터를 확인하세요.";
                        }

                        tv_result.setText(finalresult);
                    } else {//혈압이 없는 경우
                        Toast.makeText(getApplicationContext(), "혈압을 입력해야 합니다.", Toast.LENGTH_LONG).show();
                        return;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };

        Getbp getbp=new Getbp(userID,responseListener);
        RequestQueue queue= Volley.newRequestQueue(DiagnoseActivity_hbp.this);
        queue.add(getbp);

    }

}