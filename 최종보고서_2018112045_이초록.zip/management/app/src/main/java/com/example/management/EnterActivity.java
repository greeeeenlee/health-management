package com.example.management;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class EnterActivity extends AppCompatActivity {

    private Button btn_enter_bp, btn_enter_bs;
    private TextView tv_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter);

        btn_enter_bp=findViewById(R.id.btn_enter_bp);
        btn_enter_bs=findViewById(R.id.btn_enter_bs);
        tv_id=findViewById(R.id.tv_id);

        Intent intent=getIntent();
        String userID=intent.getStringExtra("userID");

        tv_id.setText(userID);

        btn_enter_bp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),EnterActivity_hbp.class);
                intent.putExtra("userID",tv_id.getText().toString());
                startActivity(intent);
            }
        });
        btn_enter_bs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(getApplicationContext(),EnterActivity_db.class);
                intent1.putExtra("userID",tv_id.getText().toString());
                startActivity(intent1);
            }
        });


    }
}