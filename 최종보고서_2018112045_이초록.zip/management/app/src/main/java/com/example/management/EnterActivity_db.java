package com.example.management;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class EnterActivity_db extends AppCompatActivity {

    private RadioGroup rg_meal;
    private RadioButton rb_morning,rb_lunch,rb_dinner;
    private String meal_result;
    private RadioGroup rg_mealtime;
    private RadioButton rb_before,rb_after;
    private String mealtime_result;
    private EditText et_bloodsugar;
    private Button btn_enter_db;
    private TextView tv_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_db);

        rg_meal=findViewById(R.id.rg_meal);
        rb_morning=findViewById(R.id.rb_morning);
        rb_lunch=findViewById(R.id.rb_lunch);
        rb_dinner=findViewById(R.id.rb_dinner);
        rg_mealtime=findViewById(R.id.rg_mealtime);
        rb_before=findViewById(R.id.rb_before);
        rb_after=findViewById(R.id.rb_after);
        et_bloodsugar=findViewById(R.id.et_bloodsugar);
        btn_enter_db=findViewById(R.id.btn_enter_db);
        tv_id=findViewById(R.id.tv_id);

        Intent intent=getIntent();
        String userID=intent.getStringExtra("userID");

        tv_id.setText(userID);

        //라디오 버튼-식사종류
        rg_meal.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i==R.id.rb_morning){
                    meal_result=rb_morning.getText().toString();
                }
                else if(i==R.id.rb_lunch){
                    meal_result=rb_lunch.getText().toString();
                }
                else{
                    meal_result=rb_dinner.getText().toString();
                }
            }
        });
        //라디오버튼-식전/식후
        rg_mealtime.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i==R.id.rb_before){
                    mealtime_result=rb_before.getText().toString();
                }
                else{
                    mealtime_result=rb_after.getText().toString();
                }
            }
        });

        //입력하기 클릭시
        btn_enter_db.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userID=tv_id.getText().toString();
                String userMeal=meal_result;
                String userMealtime=mealtime_result;
                String userBloodsugar=et_bloodsugar.getText().toString();

                if(meal_result==null){ //아침,점심,저녁 버튼을 클릭하지 않은 경우
                    Toast.makeText(EnterActivity_db.this,"식사 시간을 선택해 주세요.",Toast.LENGTH_SHORT).show();
                }
                else{//아침,점심,저녁 버튼을 클릭한 경우
                    if(mealtime_result==null){//식전,식후 버튼을 클릭하지 않은 경우
                        Toast.makeText(EnterActivity_db.this,"식전/식후를 선택해 주세요.",Toast.LENGTH_SHORT).show();
                    }
                    else{//식전,식후 버튼을 클릭한 경우
                        if(userBloodsugar.getBytes().length<=0){//혈당을 입력하지 않은 경우
                            Toast.makeText(EnterActivity_db.this,"혈당을 입력해 주세요.",Toast.LENGTH_SHORT).show();
                        }
                        else{//혈당을 입력한 경우
                            Response.Listener<String> responseListener = new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    try {
                                        JSONObject jsonObject = new JSONObject(response);
                                        boolean success = jsonObject.getBoolean("success");
                                        if (success) {//혈당 입력을 성공한 경우
                                            Toast.makeText(getApplicationContext(), "혈당이 입력되었습니다.", Toast.LENGTH_SHORT).show();
                                            finish();
                                        } else {//혈당 입력을 실패한 경우
                                            Toast.makeText(getApplicationContext(), "혈당을 입력하지 못했습니다. 다시 시도해주세요.", Toast.LENGTH_SHORT).show();
                                            return;
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }
                            };

                            //서버로 Volley를 이용해서 요청을 함.
                            EnterRequest_db enterRequest_db = new EnterRequest_db(userID, userMeal, userMealtime, userBloodsugar, responseListener);
                            RequestQueue queue = Volley.newRequestQueue(EnterActivity_db.this);
                            queue.add(enterRequest_db);
                        }
                    }
                }
            }
        });



    }
}