package com.example.management;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import static java.lang.Integer.parseInt;

public class EnterActivity_hbp extends AppCompatActivity {

    EditText et_bp_max,et_bt_min;
    Button btn_enter_hbp;
    TextView tv_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_hbp);

        et_bp_max=findViewById(R.id.et_bp_max);
        et_bt_min=findViewById(R.id.et_bp_min);
        tv_id=findViewById(R.id.tv_id);
        btn_enter_hbp=findViewById(R.id.btn_enter_hbp);

        Intent intent=getIntent();
        String userID=intent.getStringExtra("userID");

        tv_id.setText(userID);

        btn_enter_hbp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userID=tv_id.getText().toString();
                String userBpmin=et_bt_min.getText().toString();
                String userBpmax=et_bp_max.getText().toString();


                if(userBpmax.getBytes().length<=0){//최고 혈압을 입력 안한 경우
                    Toast.makeText(EnterActivity_hbp.this,"최고 혈압을 입력하세요.",Toast.LENGTH_SHORT).show();
                }
                else{//최고 혈압을 입력한 경우
                    if(userBpmin.getBytes().length<=0){//최저 혈압을 입력 안한 경우
                        Toast.makeText(EnterActivity_hbp.this,"최저 혈압을 입력하세요.",Toast.LENGTH_SHORT).show();
                    }
                    else{//최저 혈압을 입력한 경우
                        if(parseInt(userBpmax)<parseInt(userBpmin)){//최고<최저인 경우
                            Toast.makeText(EnterActivity_hbp.this,"입력값을 다시 확인하세요.",Toast.LENGTH_SHORT).show();
                        }
                        else{
                        Response.Listener<String> responseListener = new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONObject jsonObject = new JSONObject(response);
                                    boolean success = jsonObject.getBoolean("success");
                                    if (success) {//혈압 입력을 성공한 경우
                                        Toast.makeText(getApplicationContext(), "혈압이 입력되었습니다.", Toast.LENGTH_SHORT).show();
                                        finish();
                                    } else {//혈압 입력을 실패한 경우
                                        Toast.makeText(getApplicationContext(), "혈압을 입력하지 못했습니다. 다시 시도해주세요.", Toast.LENGTH_SHORT).show();
                                        return;
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        };

                        //서버로 Volley를 이용해서 요청을 함.
                        EnterRequest_hbp enterRequest_hbp = new EnterRequest_hbp(userID, userBpmin, userBpmax, responseListener);
                        RequestQueue queue = Volley.newRequestQueue(EnterActivity_hbp.this);
                        queue.add(enterRequest_hbp);
                        }
                    }
                }
            }
        });




    }
}