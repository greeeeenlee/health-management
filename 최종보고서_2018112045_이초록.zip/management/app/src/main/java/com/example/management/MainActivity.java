package com.example.management;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private TextView tv_id;
    private Button btn_management;
    private Button btn_enter,btn_diagnose,btn_mypage;  //입력하기 버튼, 진단하기 버튼,내정보 버튼

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_id=findViewById(R.id.tv_id);
        btn_management=findViewById(R.id.btn_management);
        btn_enter=findViewById(R.id.btn_enter);
        btn_diagnose=findViewById(R.id.btn_diagnose);
        btn_mypage=findViewById(R.id.btn_mypage);

        Intent intent=getIntent();
        String userID=intent.getStringExtra("userID");
        final String userGender=intent.getStringExtra("userGender");
        final String userBirth=intent.getStringExtra("userBirth");
        final String userDb=intent.getStringExtra("userDb");
        final String userHbp=intent.getStringExtra("userHbp");
        final String userHeight=intent.getStringExtra("userHeight");
        final String userWeight=intent.getStringExtra("userWeight");

        tv_id.setText(userID);

        //관리자가 회원 관리를 할 수 있게 하는 버튼-admin 로그인이 아니면 보이지 않게 설정
        if(!userID.equals("admin")){
            btn_management.setVisibility(View.GONE);
        }
        //회원 관리 버튼을 누르면 회원관리 화면(ManagementActivity)로 전환
        btn_management.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new BackgroundTask().execute();
            }
        });

        //입력하기 버튼을 누르면 입력화면(EnterActivity)으로 전환
        btn_enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(getApplicationContext(),EnterActivity.class);
                intent1.putExtra("userID",tv_id.getText().toString());
                startActivity(intent1);
            }
        });
        //진단하기 버튼을 누르면 진단화면(DiagnoseActivity)으로 전환
        btn_diagnose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2=new Intent(getApplicationContext(),DiagnoseActivity.class);
                intent2.putExtra("userID",tv_id.getText().toString());
                intent2.putExtra("userGender",userGender);
                intent2.putExtra("userBirth",userBirth);
                intent2.putExtra("userDb",userDb);
                intent2.putExtra("userHbp",userHbp);
                intent2.putExtra("userHeight",userHeight);
                intent2.putExtra("userWeight",userWeight);
                startActivity(intent2);
            }
        });
        btn_mypage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3=new Intent(getApplicationContext(),MypageActivity.class);
                intent3.putExtra("userID",tv_id.getText().toString());
                startActivity(intent3);
            }
        });
    }

    //회원 관리 버튼
    class BackgroundTask extends AsyncTask<Void,Void,String> {

        String target;
        @Override
        protected void onPreExecute(){
            target="http://dlchfhr1211.dothome.co.kr/List1.php";
        }

        @Override
        protected String doInBackground(Void... voids){
            try{
                URL url=new URL(target);
                HttpURLConnection httpURLConnection=(HttpURLConnection) url.openConnection();
                InputStream inputStream=httpURLConnection.getInputStream();
                BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream));
                String temp;
                StringBuilder stringBuilder=new StringBuilder();
                while((temp=bufferedReader.readLine())!=null){
                    stringBuilder.append(temp+"\n");
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return stringBuilder.toString().trim();
            }catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }

        @Override
        public void onProgressUpdate(Void... values){
            super.onProgressUpdate(values);
        }

        @Override
        public void onPostExecute(String result){
            Intent intent=new Intent(MainActivity.this,ManagementActivity.class);
            intent.putExtra("userList",result);
            MainActivity.this.startActivity(intent);
        }
    }
}