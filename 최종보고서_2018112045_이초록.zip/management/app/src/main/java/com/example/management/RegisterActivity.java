package com.example.management;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class RegisterActivity extends AppCompatActivity {

    //이름,아이디,비밀번호,생년월일,성별,가족력유무,키,체중
    private EditText et_id,et_pass,et_name;
    private Button btn_register;
    private RadioGroup rg_gender;
    private RadioButton rb_man,rb_woman;
    private String gender_result;
    private EditText et_birth;
    private EditText et_height,et_weight;
    private RadioGroup rg_db;
    private RadioButton rb_db_yes,rb_db_no;
    private String db_result;
    private RadioGroup rg_hbp;
    private RadioButton rb_hbp_yes,rb_hbp_no;
    private String hbp_result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {//액티비티 시작 시 처음으로 실행되는 실행주기
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //아이디 값 찾아주기
        et_id=findViewById(R.id.et_id);
        et_pass=findViewById(R.id.et_pass);
        et_name=findViewById(R.id.et_name);
        btn_register=findViewById(R.id.btn_register);
        rg_gender=findViewById(R.id.rg_gender);
        rb_man=findViewById(R.id.rb_man);
        rb_woman=findViewById(R.id.rb_woman);
        et_birth=findViewById(R.id.et_birth);
        et_height=findViewById(R.id.et_height);
        et_weight=findViewById(R.id.et_weight);
        rg_db=findViewById(R.id.rg_db);
        rb_db_yes=findViewById(R.id.rb_db_yes);
        rb_db_no=findViewById(R.id.rb_db_no);
        rg_hbp=findViewById(R.id.rg_hbp);
        rb_hbp_yes=findViewById(R.id.rb_hbp_yes);
        rb_hbp_no=findViewById(R.id.rb_hbp_no);


        //라디오 버튼-성별
        rg_gender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i==R.id.rb_man){
                    gender_result=rb_man.getText().toString();
                }
                else{
                    gender_result=rb_woman.getText().toString();
                }
            }
        });

        //라디오 버튼-당뇨
        rg_db.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i==R.id.rb_db_yes){
                    db_result="yes";
                }
                else{
                    db_result="no";
                }
            }
        });

        //라디오 버튼-고혈압
        rg_hbp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i==R.id.rb_hbp_yes){
                    hbp_result="yes";
                }
                else{
                    hbp_result="no";
                }
            }
        });

        //회원가입 버튼 클릭시 수행
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //EditText에 현재 입력되어 있는 값을 get
                String userID=et_id.getText().toString();
                String userPass=et_pass.getText().toString();
                String userName=et_name.getText().toString();
                String userGender=gender_result;
                String userBirth=et_birth.getText().toString();
                String userHeight=et_height.getText().toString();
                String userWeight=et_weight.getText().toString();
                String userDb=db_result;
                String userHbp=hbp_result;


                if(userID.getBytes().length<=0){//아이디를 입력 안한 경우
                    Toast.makeText(RegisterActivity.this,"아이디를 입력해 주세요.",Toast.LENGTH_SHORT).show();
                }
                else{//아이디를 입력한 경우
                    if(userPass.getBytes().length<=0){//비밀번호를 입력 안한 경우
                        Toast.makeText(RegisterActivity.this,"비밀번호를 입력해 주세요.",Toast.LENGTH_SHORT).show();
                    }
                    else{//비밀번호를 입력한 경우
                        if(userName.getBytes().length<=0){//이름을 입력 안한 경우
                            Toast.makeText(RegisterActivity.this,"이름을 입력해 주세요.",Toast.LENGTH_SHORT).show();
                        }
                        else{//이름을 입력한 경우
                            if(gender_result==null){//성별버튼을 클릭하지 않은 경우
                                Toast.makeText(RegisterActivity.this,"성별을 선택해 주세요.",Toast.LENGTH_SHORT).show();
                            }
                            else{//성별버튼을 클릭한 경우
                                if(userBirth.getBytes().length<=0){//생년월일을 입력 안한 경우
                                    Toast.makeText(RegisterActivity.this,"생년월일을 입력해 주세요.",Toast.LENGTH_SHORT).show();
                                }
                                else if(userBirth.getBytes().length!=8){//생년월일 형식을 맞추지 않은 경우
                                    Toast.makeText(RegisterActivity.this,"생년월일 형식을 맞춰 주세요.",Toast.LENGTH_SHORT).show();
                                }
                                else{//생년월일을 정확히 입력한 경우
                                    if(userHeight.getBytes().length<=0){//키를 입력 안한 경우
                                        Toast.makeText(RegisterActivity.this,"키를 입력해 주세요.",Toast.LENGTH_SHORT).show();
                                    }
                                    else{//키를 입력한 경우
                                        if(userWeight.getBytes().length<=0){//몸무게를 입력 안한 경우
                                            Toast.makeText(RegisterActivity.this,"몸무게를 입력해 주세요.",Toast.LENGTH_SHORT).show();
                                        }
                                        else{//몸무게를 입력한 경우
                                            if(db_result==null){//가족력-당뇨버튼을 클릭하지 않은 경우
                                                Toast.makeText(RegisterActivity.this,"가족력유무(당뇨)를 선택해 주세요.",Toast.LENGTH_SHORT).show();
                                            }
                                            else{//가족력-당뇨버튼을 클릭한 경우
                                                if(hbp_result==null){//가족력-고혈압버튼을 클릭하지 않은 경우
                                                    Toast.makeText(RegisterActivity.this,"가족력유무(고혈압)을 선택해 주세요.",Toast.LENGTH_SHORT).show();
                                                }
                                                else{//가족력-고혈압버튼을 클릭한 경우
                                                    Response.Listener<String> responseListener = new Response.Listener<String>() {
                                                        @Override
                                                        public void onResponse(String response) {
                                                            try {
                                                                JSONObject jsonObject = new JSONObject(response);
                                                                boolean success = jsonObject.getBoolean("success");
                                                                if (success) {//회원등록에 성공한 경우
                                                                    Toast.makeText(getApplicationContext(), "회원 등록에 성공했습니다.", Toast.LENGTH_SHORT).show();
                                                                    finish();
                                                                } else {//회원등록에 실패한 경우
                                                                    Toast.makeText(getApplicationContext(), "회원 등록에 실패했습니다.", Toast.LENGTH_SHORT).show();
                                                                    return;
                                                                }
                                                            } catch (JSONException e) {
                                                                e.printStackTrace();
                                                            }

                                                        }
                                                    };


                                                    //서버로 Volley를 이용해서 요청을 함.
                                                    RegisterRequest registerRequest = new RegisterRequest(userID, userPass, userName, userGender, userBirth, userHeight, userWeight, userDb, userHbp, responseListener);
                                                    RequestQueue queue = Volley.newRequestQueue(RegisterActivity.this);
                                                    queue.add(registerRequest);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });

    }
}