package com.example.management;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ShowbpActivity extends AppCompatActivity {

    private ListView listView;
    private BpListAdapter adapter;
    private List<Bloodpressure> bpList;
    private List<Bloodpressure> myList;
    private TextView tv_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showbp);

        Intent intent=getIntent();

        listView=(ListView)findViewById(R.id.listView);
        tv_id=findViewById(R.id.tv_id);
        bpList=new ArrayList<Bloodpressure>();
        myList=new ArrayList<Bloodpressure>();
        adapter=new BpListAdapter(getApplicationContext(),bpList,myList,this);
        listView.setAdapter(adapter);

        try{
            String currentID=intent.getStringExtra("userID");
            tv_id.setText(currentID);
            JSONObject jsonObject=new JSONObject(intent.getStringExtra("bpList"));
            JSONArray jsonArray=jsonObject.getJSONArray("response");
            int count=0;
            String userID,userBpmin,userBpmax,userDate;
            while(count<jsonArray.length()){
                JSONObject object=jsonArray.getJSONObject(count);
                userID=object.getString("userID");
                userBpmin=object.getString("userBpmin");
                userBpmax=object.getString("userBpmax");
                userDate=object.getString("userDate");

                Bloodpressure bloodpressure=new Bloodpressure(userID,userBpmin,userBpmax,userDate);
                bpList.add(bloodpressure);
                if(currentID.equals(userID)){
                    myList.add(bloodpressure);
                }
                count++;
            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }
}