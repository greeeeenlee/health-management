package com.example.management;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ShowbsActivity extends AppCompatActivity {

    private ListView listView;
    private BsListAdapter adapter;
    private List<Bloodsugar> bsList;
    private List<Bloodsugar> myList;
    private TextView tv_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showbs);

        Intent intent=getIntent();

        listView=(ListView)findViewById(R.id.listView);
        tv_id=findViewById(R.id.tv_id);
        bsList=new ArrayList<Bloodsugar>();
        myList=new ArrayList<Bloodsugar>();
        adapter=new BsListAdapter(getApplicationContext(),bsList,myList,this);
        listView.setAdapter(adapter);



        try{
            String currentID=intent.getStringExtra("userID");
            tv_id.setText(currentID);

            JSONObject jsonObject=new JSONObject(intent.getStringExtra("bsList"));
            JSONArray jsonArray=jsonObject.getJSONArray("response");
            int count=0;

            String userID,userMeal,userMealtime,userBloodsugar,userDate;
            while(count<jsonArray.length()){
                JSONObject object=jsonArray.getJSONObject(count);
                userID=object.getString("userID");
                userMeal=object.getString("userMeal");
                userMealtime=object.getString("userMealtime");
                userBloodsugar=object.getString("userBloodsugar");
                userDate=object.getString("userDate");

                Bloodsugar bloodsugar=new Bloodsugar(userID,userMeal,userMealtime,userBloodsugar,userDate);
                bsList.add(bloodsugar);
                if(currentID.equals(userID)){
                    myList.add(bloodsugar);
                }
                count++;
            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }

}